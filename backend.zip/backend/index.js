const route = require('./router/route');
const express = require('express');
const app = express();
const cors = require('cors');
const path = require('path')
const bodyParser = require('body-parser');
const db = require('./db/databases');
var session = require('express-session')
app.use(cors());
app.use(express.json());
app.set('trust proxy', 1) // trust first proxy
app.use(session({
  secret: 'keyboard cat',
  resave: false,
  saveUninitialized: true,
  cookie: { secure: true }
}))
app.use(bodyParser.urlencoded({extended : true}));
app.set('views',path.join(__dirname,'views'));
app.set('view engine', 'hbs');
app.use(bodyParser.json());

//tampilkan data semua
app.get('/view1', (req,res)=>{
  let sql = "SELECT * FROM kas";
  db.query(sql, (err, results)=>{
  if(err) throw err;
  res.send(JSON.stringify({"status": 200, "error": null, "array": results}));
  });
}); 

// tampilkan data berdasarkan tanggal dan nama
app.get('/view2',(req,res)=>{
  let sql = `SELECT * FROM kas WHERE nama = '${req.query.nama}' AND tanggal >= '${req.query.tanggal[0]}' AND tanggal <= '${req.query.tanggal[1]}'`;
  db.query(sql, (err, results)=>{
  if(err) throw err;
  res.send(JSON.stringify({"status": 200, "error": null, "array": results}));
  });
})

// tampilkan data berdasarkan tanggal
app.get('/view3',(req,res)=>{
  let sql = `SELECT * FROM kas WHERE tanggal >= '${req.query.tanggal[0]}' AND tanggal <= '${req.query.tanggal[1]}'`;
  db.query(sql, (err, results)=>{
  if(err) throw err;
  res.send(JSON.stringify({"status": 200, "error": null, "array": results}));
  });
})

//Edit data product berdasarkan id
app.put('/view4/:id',(req, res) => {
  // console.log(req.body.nama)
  let sql = "UPDATE kas SET nama='"+req.body.nama+"', uang='"+req.body.uang+"', tanggal='"+req.body.tanggal+"' WHERE id="+req.params.id;
  let query = db.query(sql, (err, results) => {
    if(err) throw err;
    res.send(JSON.stringify({"status": 200, "error": null, "response": results}));
  });
});

// berdasarkan id
app.get('/view5/:id',(req, res) => {
  let sql = "SELECT * FROM kas WHERE id="+req.params.id;
  let query = db.query(sql, (err, results) => {
    if(err) throw err;
    res.send(JSON.stringify({"status": 200, "error": null, "response": results}));
  });
});


//Tambahkan data product baru
app.post('/view6',(req, res) => {
  let data = {nama: req.body.nama, uang: req.body.uang, tanggal: req.body.tanggal};
  let sql = "INSERT INTO kas SET ?";
  let query = db.query(sql, data,(err, results) => {
    if(err) throw err;
    res.send(JSON.stringify({"status": 200, "error": null, "response": results}));
  });
});

//Delete data product berdasarkan id
app.delete('/view7/:id',(req, res) => {
  let sql = "DELETE FROM kas WHERE id="+req.params.id+"";
  let query = db.query(sql, (err, results) => {
    if(err) throw err;
      res.send(JSON.stringify({"status": 200, "error": null, "response": results}));
  });
});

app.post('/auth', function(request, response) {
	var username = request.body.username;
	var password = request.body.password;
  var today = new Date();
  var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
  var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
  var dateTime = date+' '+time;
  var idUser = 0;
	if (username && password) {
		db.query('SELECT * FROM login WHERE nama = ? AND password = ?', [username, password], function(error, results, fields) {
			if (results.length > 0) {
				request.session.loggedin = true;
        let ses = request.session.loggedin;
				request.session.username = username;

        response.send(JSON.stringify({flag: "Y", message: "Login Success", session: ses, user: username, date: dateTime}))

        results.forEach(element => {
          idUser = element.id
        });
        let sql = "UPDATE login SET login_date='"+dateTime+"' WHERE id="+idUser;
        let query = db.query(sql, (err, results) => {
          if(err) throw err;
        });
        
			} else {
				response.send(JSON.stringify({flag: "N", message: 'Incorrect Username and/or Password!'}));
			}			
			response.end();
		});
	} else {
    response.send(JSON.stringify({flag: "N", message: "Please enter Username and Password!"}))
		response.end();
	}
});

//Edit data product berdasarkan id
app.put('/authEdit/:id',(req, res) => {
  // console.log(req.body.nama)
  let sql = "UPDATE login SET username='"+req.body.username+"', password='"+req.body.password+"' WHERE id="+req.params.id;
  let query = db.query(sql, (err, results) => {
    if(err) throw err;
    res.send(JSON.stringify({"status": 200, "error": null, "response": results}));
  });
});

//Tambahkan data product baru
app.post('/AddAuth',(req, res) => {
  let data = {username: req.body.username, password: req.body.password};
  let sql = "INSERT INTO login SET ?";
  let query = db.query(sql, data,(err, results) => {
    if(err) throw err;
    res.send(JSON.stringify({"status": 200, "error": null, "response": results}));
  });
});

app.listen(2021, () => {
  console.log('Server is running at port 8000');
});