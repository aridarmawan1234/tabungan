const db = require('../db/databases')

module.exports = {
    get: function(results){
    let sql = "SELECT * FROM kas";
    db.query(sql, (err, res)=>{
        if(err) throw err;
        results(res);
        });
    }  
}