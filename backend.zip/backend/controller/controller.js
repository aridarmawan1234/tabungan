const db = require('../db/databases')
const ModelProduct = require('../model/model');
module.exports = {
    getAll: function (req,res){
        ModelProduct.get(function(err,results){
            if(err)res.send(err)
            res.send(results)
        })
    }
}